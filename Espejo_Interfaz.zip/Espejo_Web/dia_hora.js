// Con esta funcion agregamos un 0 a la izquierda si el numero tiene un solo digito
function formatearNumero(numero) {
    return numero < 10 ? `0${numero}` : numero;
}

// Con esta funcion actualizamos la fecha y la hora con la de nuestro sistema
function actualizarFechaHora() {
    const fechaHoraActual = new Date();

    const ano = fechaHoraActual.getFullYear();
    const mes = fechaHoraActual.getMonth() + 1;
    const dia = fechaHoraActual.getDate();
    const formatoMes = formatearNumero(mes);
    const formatoDia = formatearNumero(dia);
    const cadenaFecha = `${ano}-${formatoMes}-${formatoDia}`;

    const horas = fechaHoraActual.getHours();
    const minutos = fechaHoraActual.getMinutes();
    const segundos = fechaHoraActual.getSeconds();
    const formatoHoras = formatearNumero(horas);
    const formatoMinutos = formatearNumero(minutos);
    const formatoSegundos = formatearNumero(segundos);
    const cadenaHora = `${formatoHoras}:${formatoMinutos}:${formatoSegundos}`;

    document.getElementById('fecha').innerText = cadenaFecha;
    document.getElementById('hora').innerText = cadenaHora;
}

// Aqui ejecutamos la funcion function actualizarFechaHora() cada medio segundo
setInterval(actualizarFechaHora, 500);

actualizarFechaHora();
