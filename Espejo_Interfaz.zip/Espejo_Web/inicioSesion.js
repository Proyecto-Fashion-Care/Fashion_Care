function redirigirPaginaSesion() {
    window.location.href = 'inicioSesion.html';
}
function redirigirPaginaSinSesion() {
    window.location.href = 'inicio.html';
}
function redirigirPaginaMusica() {
    window.location.href = 'musica.html';
}