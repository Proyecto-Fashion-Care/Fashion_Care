const musicData = [
    { artist: 'Artista1', song: 'Canción1', audio: 'cancion1.mp3' },
    { artist: 'Artista2', song: 'Canción2', audio: 'cancion2.mp3' },
    // Agregamos más datos según sea necesario
];
// Función para buscar música
function buscarMusica() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const filteredMusic = musicData.filter(item =>
        item.artist.toLowerCase().includes(searchTerm) ||
        item.song.toLowerCase().includes(searchTerm)
    );

    displayMusicList(filteredMusic);
}

// Función para mostrar la lista de música
function displayMusicList(musicList) {
    const listContainer = document.getElementById('musicList');
    listContainer.innerHTML = '';

    musicList.forEach(item => {
        const listItem = document.createElement('li');
        listItem.textContent = `${item.artist} - ${item.song}`;
        listItem.onclick = () => playMusic(item.audio);
        listContainer.appendChild(listItem);
    });

}

// Función para reproducir música
function playMusic(audioFile) {
    const audioPlayer = document.getElementById('audioPlayer');
    audioPlayer.src = audioFile;
    audioPlayer.play();
}