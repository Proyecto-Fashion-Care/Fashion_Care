function redirigirTiempoMeteorologico() {
    window.location.href = '#tiempo.html';
}